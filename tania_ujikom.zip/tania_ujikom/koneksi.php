<?php
$koneksi = mysqli_connect('localhost', 'root', '','tania_praukk');
?>